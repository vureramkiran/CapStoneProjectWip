import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewlists',
  templateUrl: './viewlists.component.html',
  styleUrls: ['./viewlists.component.css']
})
export class ViewlistsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
