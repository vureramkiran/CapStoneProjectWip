import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
const subscriptionID="5a23b00f-d892-45b2-bcab-84e1357297bd";//`5a23b00f-d892-45b2-bcab-84e1357297bd`;
const resourceGroupName=`VirtualMachine`;
@Injectable({
  providedIn: 'root'
})

export class RestService {
  
  constructor(private http:HttpClient) {
    

   }
   private extractData(res: Response) {
    let body = res;
    return body || { };
  }
  
  addVM (vmDetails): Observable<any> {

    const endpoint = `https://management.azure.com/subscriptions/${subscriptionID}/resourceGroups/${resourceGroupName}/providers/Microsoft.Compute/virtualMachines/${vmDetails.name}?api-version=2019-03-01`;
    const httpOptions = {
      headers: new HttpHeaders({
          'Access-Control-Allow-Origin': 'http://localhost:4200', // -->Add this line
          'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE,OPTIONS',
          'Access-Control-Allow-Headers': '*',
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization':`Bearer ${accessToken}`
      })
  };
    var requestBody={
      "location":vmDetails.location,
      "properties": {
        "hardwareProfile": {
          "vmSize": "Standard_D2_v2"
        },
        "storageProfile": {
          "imageReference": {
            "sku": "2016-Datacenter",
            "publisher": "MicrosoftWindowsServer",
            "version": "latest",
            "offer": "WindowsServer"
          },
          "osDisk": {
            "caching": "ReadWrite",
            "managedDisk": {
              "storageAccountType": "Standard_LRS"
            },
            "name": "myVMosdisk",
            "createOption": "FromImage"
          },
          "dataDisks": [
            {
              "diskSizeGB": 1023,
              "createOption": "Empty",
              "lun": 0
            },
            {
              "diskSizeGB": 1023,
              "createOption": "Empty",
              "lun": 1
            }
          ]
        },
        "osProfile": {
          "adminUsername": "myUserName",
          "computerName": `${vmDetails.name}`,
          "adminPassword": "Welcome1!"
        },
        "networkProfile": {
          "networkInterfaces": [
            {
              "id": "/subscriptions/5a23b00f-d892-45b2-bcab-84e1357297bd/resourceGroups/VirtualMachine/providers/Microsoft.Network/networkInterfaces/secondvirtualmachine521",
              "properties": {
                "primary": true
              }
            }
          ]
        }
      }
    };
  
    return this.http.put<any>(endpoint, JSON.stringify(requestBody), httpOptions).pipe(
      tap((vmDetails) => console.log(`added VM w/ name=${vmDetails.name}`)),
      catchError(this.handleError<any>('addVM'))
    );
  }
  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
