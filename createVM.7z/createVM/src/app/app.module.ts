import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { VMCreateComponent } from './vmcreate/vmcreate.component';
import { ViewlistsComponent } from './viewlists/viewlists.component';
import { HttpClientModule } from '@angular/common/http';
import{OAuthService, UrlHelperService} from 'angular-oauth2-oidc';
import { OAuthModule } from 'angular-oauth2-oidc';



@NgModule({
  declarations: [
    AppComponent,
    VMCreateComponent,
    ViewlistsComponent,
    
    ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    OAuthModule.forRoot()
   
   
  ],
  providers: [
    OAuthService,
    UrlHelperService,
    
  
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
