import { Component, OnInit, Input } from '@angular/core';
import { RestService } from '../rest.service';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';

const tenantId=`a08eb642-2652-4a52-b3bf-232fa2341243`;
const clientid=`5ed1dab5-0867-4fe7-81d1-1a04694d4b21`;
const clientsecret=`6]I[uj3me@nj9Q3YFBFJmADsr-tucc5t`;
@Component({
  selector: 'app-vmcreate',
  templateUrl: './vmcreate.component.html',
  styleUrls: ['./vmcreate.component.css']
})

export class VMCreateComponent implements OnInit {
  @Input() vmDetails = { name:'', location: '' };
 constructor(public rest:RestService,private http:HttpClient) { }

  ngOnInit() {
  }
  getAccessToken():Observable<any>{
    const endpoint = `https://login.microsoftonline.com/${tenantId}/oauth2/token`;
    const httpOptions = {
      headers: new HttpHeaders({
        'Access-Control-Allow-Origin': 'http://localhost:4200', // -->Add this line
        'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE,OPTIONS',
        'Access-Control-Allow-Headers': '*',
        'Content-Type': 'application/x-www-form-urlencoded',
           
      })
  };
  var requestBody={
    'grant_type':`client_credentials`,
    'client_id':`${clientid}`,
    'client_secret':`${clientsecret}`,
'resource':`https://management.core.windows.net/`
  };
  return this.http.post<any>(endpoint, JSON.stringify(requestBody), httpOptions).pipe(
    
    catchError(this.handleError<any>('addVM'))
  );
  }
  addVM() {
   
  this.getAccessToken().subscribe(response=>{
    let atoken=response.access_token;
    this.rest.addVM(this.vmDetails,response.access_token).subscribe((result) => {
      console.log("VM successfully created");
    }, (err) => {
      console.log(err);
    });
  });
  }
  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }


}
